export interface Ingredient {
  ingredient: string;
  unit: string;
  amount: number;
  isEdit: boolean;
}
