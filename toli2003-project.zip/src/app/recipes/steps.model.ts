export interface StepsModel {
  description: string;
  edit: boolean;
}
